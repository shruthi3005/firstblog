class WelcopmeController < ApplicationController
  def index
  end
end
